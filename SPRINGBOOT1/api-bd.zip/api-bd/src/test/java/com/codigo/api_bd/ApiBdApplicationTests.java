package com.codigo.api_bd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBdApplicationTests {

	@Test
	void contextLoads() {
	}

}
