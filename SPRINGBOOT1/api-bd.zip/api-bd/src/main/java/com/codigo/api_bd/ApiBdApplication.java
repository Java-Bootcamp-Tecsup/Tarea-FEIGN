package com.codigo.api_bd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBdApplication.class, args);
	}

}
